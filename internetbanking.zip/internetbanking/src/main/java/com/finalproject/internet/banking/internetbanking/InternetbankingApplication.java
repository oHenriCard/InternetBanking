package com.finalproject.internet.banking.internetbanking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InternetbankingApplication {

	public static void main(String[] args) {
		SpringApplication.run(InternetbankingApplication.class, args);
	}

}
