package com.finalproject.internet.banking.internetbanking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InternetbankingApplicationTests {

	@Test
	void contextLoads() {
	}

}
